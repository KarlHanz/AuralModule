# Newsblog

## 2020
* **08.09.2020** Added hints on how to increase the flash memory.  
* **03.01.2020** Added screenshots. People love screenshots!  
* **02.01.2020** Tested the tool with Virtualbox. Works great.  

## 2019
* **03.12.2019** Now Rufus is the recommended copying tool.  
* **27.08.2019** New Linux upload and repair tool. The make command now works with Debian/Ubuntu/Mint. New **V1.1** release.    
* **01.08.2019** Better handling instructions.  
* **31.07.2019** With a lot of help by Reinhard Max i finally released a reworked version which should work for almost everyone.  

## 2018  
* **21.11.2018** Added a hint in the README: The tool is compiled for x86_64 CPUs. A 32Bit verison will follow.  
* **17.03.2018** Added support for 8, 64 and 128 MBit modules.  
* **16.03.2018** Finished the README manual and completed the repository.  
* **15.03.2018** Initial release.  
