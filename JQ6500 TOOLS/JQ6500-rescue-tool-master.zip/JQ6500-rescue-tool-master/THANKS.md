# Thanks

The following people helped me to bring this (hopefully) usefull tool to life:

* **Reinhard Max** - creator of the *jq6500* tool, for the tool itself, the reworked MLL ISO and lots of advices.  
* **James Sleeman** - the "re-inventer" of the module, for several hints, like identifying the flash size.  
* **carlosmojopicon** - bugfixes.  
* **DDDanny** - bugfixes.  
* **"Nickneck"** - translating the JQ6500 upload interface from Chinese to English.  
* **"feldon30"** - for testing - and failing with Unetbootin. Now Rufus is the recommended tool.  

Used Ressources:

* **JQ6500 Linux tool** - [Reinhard Max](https://chiselapp.com/user/rmax/repository/jq6500/home)  
* **JQ6500 Arduino library and much more** - [James Sleeman](https://github.com/sleemanj/JQ6500_Serial)  
* **Minimal Linux Live** - [Minimal Linux Live](http://minimal.linux-bg.org/#home)  
