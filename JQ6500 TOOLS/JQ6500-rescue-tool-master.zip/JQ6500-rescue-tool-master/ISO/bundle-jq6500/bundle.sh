#!/bin/sh

set -e

./01_get.sh
./02_build.sh

cd $SRC_DIR
